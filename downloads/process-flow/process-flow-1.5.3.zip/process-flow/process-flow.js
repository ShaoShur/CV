define(['qlik', 'jquery', 'css!./process-flow.css'], function (qlik, $) {
  'use strict';

  var NODE_WIDTH = 144;
  var NODE_HEIGHT = 54;
  var HORIZONTAL_STEP = 190;
  var VERTICAL_STEP = 92;
  var LANE_STEP = 86;
  var MIN_ZOOM = 0.35;
  var MAX_ZOOM = 3;

  function escapeHtml(value) {
    return $('<div>').text(value == null ? '' : String(value)).html();
  }

  function finiteNumber(value) {
    return Number.isFinite(value) ? value : 0;
  }

  function durationColor(value, maximum) {
    var ratio = maximum ? Math.min(1, value / maximum) : 0;
    return ratio > 0.66 ? '#9B5C52' : ratio > 0.33 ? '#B58A66' : '#7B8475';
  }

  function readEdges(layout) {
    var pages = (layout.qHyperCube || {}).qDataPages || [];
    var matrix = (pages[0] || {}).qMatrix || [];

    return matrix.map(function (row) {
      return {
        from: row[0].qText,
        to: row[1].qText,
        count: finiteNumber(row[2].qNum),
        duration: finiteNumber(row[3].qNum),
        fromElement: row[0].qElemNumber,
        toElement: row[1].qElemNumber
      };
    }).filter(function (edge) {
      return edge.from && edge.to;
    });
  }

  function buildGraph(edges) {
    var nodes = {};
    var incoming = {};
    var outgoing = {};

    edges.forEach(function (edge) {
      nodes[edge.from] = true;
      nodes[edge.to] = true;
      (incoming[edge.to] || (incoming[edge.to] = [])).push(edge.from);
      (outgoing[edge.from] || (outgoing[edge.from] = [])).push(edge.to);
    });

    return { nodes: nodes, incoming: incoming, outgoing: outgoing };
  }

  // Shortest-path layering remains finite when the process contains returns or cycles.
  function calculateLevels(graph) {
    var names = Object.keys(graph.nodes).sort();
    var roots = names.filter(function (name) {
      return !(graph.incoming[name] || []).length;
    });
    var levels = {};
    var queue = roots.length ? roots.slice() : names.slice(0, 1);

    queue.forEach(function (name) { levels[name] = 0; });
    for (var index = 0; index < queue.length; index += 1) {
      var source = queue[index];
      (graph.outgoing[source] || []).forEach(function (target) {
        if (levels[target] === undefined) {
          levels[target] = levels[source] + 1;
          queue.push(target);
        }
      });
    }

    // Disconnected components receive their own finite breadth-first traversal.
    names.forEach(function (name) {
      if (levels[name] !== undefined) return;
      levels[name] = 0;
      queue = [name];
      for (var i = 0; i < queue.length; i += 1) {
        (graph.outgoing[queue[i]] || []).forEach(function (target) {
          if (levels[target] === undefined) {
            levels[target] = levels[queue[i]] + 1;
            queue.push(target);
          }
        });
      }
    });

    return levels;
  }

  function groupByLevel(nodes, levels) {
    var groups = {};
    Object.keys(nodes).forEach(function (name) {
      var level = levels[name];
      (groups[level] || (groups[level] = [])).push(name);
    });
    Object.keys(groups).forEach(function (level) { groups[level].sort(); });
    return groups;
  }

  function calculateLayout(graph, orientation, width, height) {
    var levels = calculateLevels(graph);
    var groups = groupByLevel(graph.nodes, levels);
    var layerKeys = Object.keys(groups).map(Number).sort(function (a, b) { return a - b; });
    var maximumGroup = Math.max.apply(null, layerKeys.map(function (key) { return groups[key].length; }));
    var canvasWidth = orientation === 'horizontal'
      ? Math.max(width, 180 + Math.max(0, layerKeys.length - 1) * HORIZONTAL_STEP)
      : Math.max(width, 200 + Math.max(0, maximumGroup - 1) * HORIZONTAL_STEP);
    var canvasHeight = orientation === 'vertical'
      ? Math.max(height, 140 + Math.max(0, layerKeys.length - 1) * VERTICAL_STEP)
      : Math.max(height, 120 + Math.max(0, maximumGroup - 1) * LANE_STEP);
    var verticalOffset = (canvasHeight - Math.max(0, layerKeys.length - 1) * VERTICAL_STEP) / 2;
    var horizontalOffset = (canvasWidth - Math.max(0, layerKeys.length - 1) * HORIZONTAL_STEP) / 2;
    var positions = {};

    layerKeys.forEach(function (level, layerIndex) {
      var names = groups[level];
      if (orientation === 'vertical') {
        var y = verticalOffset + layerIndex * VERTICAL_STEP;
        var startX = (canvasWidth - Math.max(0, names.length - 1) * HORIZONTAL_STEP) / 2;
        names.forEach(function (name, laneIndex) {
          positions[name] = { x: startX + laneIndex * HORIZONTAL_STEP, y: y };
        });
      } else {
        var x = horizontalOffset + layerIndex * HORIZONTAL_STEP;
        var startY = (canvasHeight - Math.max(0, names.length - 1) * LANE_STEP) / 2;
        names.forEach(function (name, laneIndex) {
          positions[name] = { x: x, y: startY + laneIndex * LANE_STEP };
        });
      }
    });

    return positions;
  }

  function contentBounds(positions) {
    var names = Object.keys(positions);
    var xs = names.map(function (name) { return positions[name].x; });
    var ys = names.map(function (name) { return positions[name].y; });
    var minX = Math.min.apply(null, xs) - NODE_WIDTH / 2 - 10;
    var maxX = Math.max.apply(null, xs) + NODE_WIDTH / 2 + 10;
    var minY = Math.min.apply(null, ys) - NODE_HEIGHT / 2 - 11;
    var maxY = Math.max.apply(null, ys) + NODE_HEIGHT / 2 + 11;
    return { minX: minX, minY: minY, width: maxX - minX, height: maxY - minY };
  }

  function edgeGeometry(edge, positions, orientation) {
    var source = positions[edge.from];
    var target = positions[edge.to];
    var labelX = (source.x + target.x) / 2;
    var labelY = (source.y + target.y) / 2;
    var path;

    if (orientation === 'vertical') {
      var dy = (target.y - source.y) * 0.42;
      path = 'M ' + source.x + ' ' + (source.y + NODE_HEIGHT / 2) +
        ' C ' + source.x + ' ' + (source.y + NODE_HEIGHT / 2 + dy) +
        ', ' + target.x + ' ' + (target.y - NODE_HEIGHT / 2 - dy) +
        ', ' + target.x + ' ' + (target.y - NODE_HEIGHT / 2);
    } else {
      var dx = (target.x - source.x) * 0.42;
      path = 'M ' + (source.x + NODE_WIDTH / 2) + ' ' + source.y +
        ' C ' + (source.x + NODE_WIDTH / 2 + dx) + ' ' + source.y +
        ', ' + (target.x - NODE_WIDTH / 2 - dx) + ' ' + target.y +
        ', ' + (target.x - NODE_WIDTH / 2) + ' ' + target.y;
    }

    return { path: path, labelX: labelX, labelY: labelY };
  }

  function renderEdge(edge, positions, orientation, maximumCount, maximumDuration) {
    var geometry = edgeGeometry(edge, positions, orientation);
    var width = 1.15 + 2.15 * Math.sqrt(edge.count / (maximumCount || 1));
    var color = durationColor(edge.duration, maximumDuration);
    var happyPath = edge.count >= maximumCount * 0.7 ? ' pf-happy' : '';
    var tooltip = escapeHtml(edge.count + ' кейсов · ' + edge.duration.toFixed(1) + ' ч');
    var countY = orientation === 'vertical' ? -4 : -17;
    var durationY = orientation === 'vertical' ? 9 : -6;

    return {
      path: '<path class="pf-edge' + happyPath + '" data-from="' + edge.fromElement +
      '" data-to="' + edge.toElement + '" d="' + geometry.path + '" stroke="' + color +
      '" stroke-width="' + width.toFixed(2) + '"><title>' + tooltip + '</title></path>',
      label: '<g class="pf-edge-label" transform="translate(' + geometry.labelX + ' ' + geometry.labelY + ')">' +
      '<text class="pf-edge-count" x="0" y="' + countY + '">' + edge.count + '</text>' +
      '<text class="pf-edge-duration" x="0" y="' + durationY + '">' + edge.duration.toFixed(1) + ' ч</text>' +
      '<title>' + tooltip + '</title></g>'
    };
  }

  function nodeCaseCount(name, graph, edges) {
    return edges.filter(function (edge) {
      return edge.to === name || (!(graph.incoming[name] || []).length && edge.from === name);
    }).reduce(function (maximum, edge) {
      return Math.max(maximum, edge.count);
    }, 0);
  }

  function renderNode(name, position, count) {
    return '<g class="pf-node" transform="translate(' + (position.x - NODE_WIDTH / 2) + ',' +
      (position.y - NODE_HEIGHT / 2) + ')"><rect width="' + NODE_WIDTH + '" height="' + NODE_HEIGHT +
      '"/><text x="' + NODE_WIDTH / 2 + '" y="23">' + escapeHtml(name) +
      '</text><text class="pf-count" x="' + NODE_WIDTH / 2 + '" y="41">' + count + ' кейсов</text></g>';
  }

  function initialView(instance, orientation, width, height, bounds) {
    var fitScale = Math.min((width - 28) / bounds.width, (height - 28) / bounds.height, 1.15);
    var current = instance._pfView;
    if (!current || current.orientation !== orientation || current.baseW !== width || current.baseH !== height) {
      current = {
        orientation: orientation,
        baseW: width,
        baseH: height,
        scale: fitScale,
        x: (width - bounds.width * fitScale) / 2 - bounds.minX * fitScale,
        y: (height - bounds.height * fitScale) / 2 - bounds.minY * fitScale
      };
      instance._pfView = current;
    }
    return current;
  }

  return {
    initialProperties: {
      qHyperCubeDef: {
        qDimensions: [],
        qMeasures: [],
        qInitialDataFetch: [{ qWidth: 4, qHeight: 500 }]
      },
      flowOrientation: 'horizontal'
    },
    definition: {
      type: 'items',
      component: 'accordion',
      items: {
        dimensions: { uses: 'dimensions', min: 2, max: 2 },
        measures: { uses: 'measures', min: 2, max: 2 },
        sorting: { uses: 'sorting' },
        appearance: {
          uses: 'settings',
          items: {
            orientation: {
              ref: 'flowOrientation',
              label: 'Ориентация',
              type: 'string',
              component: 'dropdown',
              options: [
                { value: 'horizontal', label: 'Горизонтально' },
                { value: 'vertical', label: 'Вертикально' }
              ],
              defaultValue: 'horizontal'
            }
          }
        }
      }
    },
    support: { snapshot: true, export: false, exportData: true },

    paint: function ($element, layout) {
      var instance = this;
      var edges = readEdges(layout);
      if (!edges.length) {
        $element.html('<div class="pf-empty">Нет переходов для выбранного контекста</div>');
        return qlik.Promise.resolve();
      }

      var orientation = layout.flowOrientation || 'horizontal';
      var graph = buildGraph(edges);
      var baseWidth = Math.max(720, $element.width() || 900);
      var baseHeight = Math.max(420, ($element.height() || 520) - 40);
      var positions = calculateLayout(graph, orientation, baseWidth, baseHeight);
      var bounds = contentBounds(positions);
      var view = initialView(instance, orientation, baseWidth, baseHeight, bounds);
      var maximumCount = Math.max.apply(null, edges.map(function (edge) { return edge.count; }));
      var maximumDuration = Math.max.apply(null, edges.map(function (edge) { return edge.duration; }));
      var html = '<div class="pf-root ' + (orientation === 'vertical' ? 'pf-vertical' : 'pf-horizontal') + '">' +
        '<div class="pf-toolbar"><span><i class="pf-dot" style="background:#7B8475"></i>быстро</span>' +
        '<span><i class="pf-dot" style="background:#B58A66"></i>средне</span>' +
        '<span><i class="pf-dot" style="background:#9B5C52"></i>узкое место</span>' +
        '<span>колесо = зум · drag = перемещение</span><span class="pf-orientation">' +
        (orientation === 'vertical' ? 'вертикальная карта' : 'горизонтальная карта') + '</span>' +
        '<span class="pf-zoom"><button type="button" class="pf-zoom-out" title="Уменьшить">−</button>' +
        '<span class="pf-zoom-value">' + Math.round(view.scale * 100) + '%</span>' +
        '<button type="button" class="pf-zoom-in" title="Увеличить">+</button></span></div>' +
        '<svg class="pf-svg" viewBox="0 0 ' + baseWidth + ' ' + baseHeight + '">' +
        '<g class="pf-viewport" transform="translate(' + view.x + ' ' + view.y + ') scale(' + view.scale + ')">';

      var renderedTransitions = edges.slice().sort(function (a, b) { return a.count - b.count; }).map(function (edge) {
        return renderEdge(edge, positions, orientation, maximumCount, maximumDuration);
      });
      renderedTransitions.forEach(function (transition) { html += transition.path; });
      renderedTransitions.forEach(function (transition) { html += transition.label; });
      Object.keys(positions).forEach(function (name) {
        html += renderNode(name, positions[name], nodeCaseCount(name, graph, edges));
      });
      html += '</g></svg></div>';
      $element.html(html);

      var $svg = $element.find('.pf-svg');
      var $viewport = $element.find('.pf-viewport');
      var eventNamespace = '.processflow-' + layout.qInfo.qId;
      var drag = { active: false, moved: false, startX: 0, startY: 0, viewX: 0, viewY: 0 };

      function renderView() {
        instance._pfView = view;
        $viewport.attr('transform', 'translate(' + view.x + ' ' + view.y + ') scale(' + view.scale + ')');
        $element.find('.pf-zoom-value').text(Math.round(view.scale * 100) + '%');
      }

      function zoomAt(nextScale, centerX, centerY) {
        nextScale = Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, Math.round(nextScale * 100) / 100));
        var ratio = nextScale / view.scale;
        view.x = centerX - (centerX - view.x) * ratio;
        view.y = centerY - (centerY - view.y) * ratio;
        view.scale = nextScale;
        renderView();
      }

      $svg[0].addEventListener('wheel', function (event) {
        event.preventDefault();
        var rectangle = this.getBoundingClientRect();
        var centerX = (event.clientX - rectangle.left) * baseWidth / rectangle.width;
        var centerY = (event.clientY - rectangle.top) * baseHeight / rectangle.height;
        zoomAt(view.scale * (event.deltaY < 0 ? 1.12 : 1 / 1.12), centerX, centerY);
      }, { passive: false });

      $svg.on('mousedown', function (event) {
        if (event.button !== 0) return;
        drag = { active: true, moved: false, startX: event.clientX, startY: event.clientY, viewX: view.x, viewY: view.y };
        $svg.addClass('pf-dragging');
        event.preventDefault();
      });

      $(document).off(eventNamespace)
        .on('mousemove' + eventNamespace, function (event) {
          if (!drag.active) return;
          var rectangle = $svg[0].getBoundingClientRect();
          var dx = (event.clientX - drag.startX) * baseWidth / rectangle.width;
          var dy = (event.clientY - drag.startY) * baseHeight / rectangle.height;
          if (Math.abs(dx) + Math.abs(dy) > 3) drag.moved = true;
          view.x = drag.viewX + dx;
          view.y = drag.viewY + dy;
          renderView();
        })
        .on('mouseup' + eventNamespace, function () {
          if (!drag.active) return;
          drag.active = false;
          $svg.removeClass('pf-dragging');
          setTimeout(function () { drag.moved = false; }, 0);
        });

      $element.find('.pf-edge').on('click', function (event) {
        if (drag.moved) {
          event.preventDefault();
          event.stopPropagation();
          return;
        }
        var from = parseInt($(this).attr('data-from'), 10);
        var to = parseInt($(this).attr('data-to'), 10);
        instance.backendApi.selectValues(0, [from], false).then(function () {
          return instance.backendApi.selectValues(1, [to], false);
        });
      });

      $element.find('.pf-zoom-out').on('click', function (event) {
        event.preventDefault();
        event.stopPropagation();
        zoomAt(view.scale / 1.15, baseWidth / 2, baseHeight / 2);
      });
      $element.find('.pf-zoom-in').on('click', function (event) {
        event.preventDefault();
        event.stopPropagation();
        zoomAt(view.scale * 1.15, baseWidth / 2, baseHeight / 2);
      });

      return qlik.Promise.resolve();
    }
  };
});
